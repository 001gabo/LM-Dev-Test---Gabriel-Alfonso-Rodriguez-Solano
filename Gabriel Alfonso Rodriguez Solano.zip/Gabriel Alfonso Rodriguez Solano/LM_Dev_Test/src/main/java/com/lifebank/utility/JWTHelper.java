package com.lifebank.utility;

import com.lifebank.pojo.login.request.LoginPojoRequest;

import io.jsonwebtoken.Claims;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class JWTHelper {


	public String EncryptJWT(LoginPojoRequest loginRequest, String iNetAddress) {
		String sch = null;
		Map<String, Object> mapJWT = new HashMap<String, Object>();
		 
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		now = now.plusMinutes(30);
		
		mapJWT.put("idUser", loginRequest.getUser());
		mapJWT.put("ipAddress", iNetAddress);
		mapJWT.put("expiration-datetime", dtf.format(now));
		
		
		JWT jwt = new JWT(mapJWT,
				"jJDBnzswYhK53XQlaHJxF4fZW_UJ6WxGsZmbFM7vqiLNtJ98O6GZWo4EpADogg1wW57cZ03aUHTrd2b8T-MW1eEUT3eT4nQdUl_0KYDHBuE-TTB2KizeQlVK74EdyoE-1uDOc9KSaIzOget12JexeloRRRUXXWXJOWM_elOfePI2UcPFTAEWOBQLfZAo1TqK65V5LKR1qD3jhZeZgzIjb-n_pq8VoLe903-wgjf40T3BX8nctqmJBfic6HE0uK4h27AGLH5skCxbKZXoDPe17gyw7Q0hPMjgjvPoxA5_IWf9hECSqbunoxYP-VQ4nvZcdeqkAMP8mBDYoqrBD_vjTQ",
				"token-lifebank",
				"LifeMiles",
				Long.parseLong("1800000") 
				);
		sch = jwt.generate();
		
		return sch;
	}
	
	public ArrayList<String> DecryptJWT(String sch) {
			
		JWT jwt = new JWT("jJDBnzswYhK53XQlaHJxF4fZW_UJ6WxGsZmbFM7vqiLNtJ98O6GZWo4EpADogg1wW57cZ03aUHTrd2b8T-MW1eEUT3eT4nQdUl_0KYDHBuE-TTB2KizeQlVK74EdyoE-1uDOc9KSaIzOget12JexeloRRRUXXWXJOWM_elOfePI2UcPFTAEWOBQLfZAo1TqK65V5LKR1qD3jhZeZgzIjb-n_pq8VoLe903-wgjf40T3BX8nctqmJBfic6HE0uK4h27AGLH5skCxbKZXoDPe17gyw7Q0hPMjgjvPoxA5_IWf9hECSqbunoxYP-VQ4nvZcdeqkAMP8mBDYoqrBD_vjTQ");
		Claims claims = jwt.extract(sch);
		ArrayList<String> jwtDecryptList = new ArrayList<String>();
		
		jwtDecryptList.add(claims.get("idUser").toString()); 
		jwtDecryptList.add(claims.get("ipAddress").toString()); 
		jwtDecryptList.add(claims.get("expiration-datetime").toString()); 
		
		return jwtDecryptList;
	}
}
