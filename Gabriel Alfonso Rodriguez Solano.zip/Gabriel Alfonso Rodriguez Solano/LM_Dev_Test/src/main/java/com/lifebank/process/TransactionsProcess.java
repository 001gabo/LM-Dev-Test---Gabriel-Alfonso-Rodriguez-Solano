package com.lifebank.process;
  
import java.time.LocalDate; 
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.lifebank.entity.AccountEntity;
import com.lifebank.entity.TransactionsEntity;
import com.lifebank.entity.UserEntity;
import com.lifebank.pojo.transaccion.response.CuentaBancariaPojoResponse;
import com.lifebank.pojo.transaccion.response.PrestamoBancarioPojoResponse;
import com.lifebank.pojo.transaccion.response.TarjetaCreditoPojoResponse;
import com.lifebank.pojo.transaccion.response.Transaction;
import com.lifebank.repository.AccountRepository;
import com.lifebank.repository.TransactionsRepository;
import com.lifebank.repository.UserRepository;
import com.lifebank.utility.DateFormat;
import com.lifebank.utility.JWTHelper;
 
 
@Service("TransactionsProcess")
public class TransactionsProcess {
 
	private TransactionsRepository transactionRepositoryResponse;
	private UserRepository userRepository;
	private AccountRepository accountRepository; 
	
	public TransactionsProcess(TransactionsRepository transactionRepositoryResponse, UserRepository userRepository,AccountRepository accountRepository){
		this.transactionRepositoryResponse = transactionRepositoryResponse;
		this.userRepository =  userRepository;
		this.accountRepository = accountRepository;
	}
	
	public ResponseEntity<?> getTransaccionesProducto(String accountID, String start, String end ,String sch) { 	
		DateFormat dateFormat = new DateFormat();
		LocalDate StartDate, EndDate;
		long monthsDiff ;  
		
		Transaction transactionObj = new Transaction();
		List<TransactionsEntity> transactionListEntity = new ArrayList<TransactionsEntity>();
		
		List<Transaction> transactionList = new ArrayList<Transaction>(); 
		
		UserEntity userEntity = new UserEntity();
		List<AccountEntity> accountList = new ArrayList<AccountEntity>(); 
		
		JWTHelper jWTHelper  = new JWTHelper();
		ArrayList<String> jwtDecryptList = new ArrayList<String>(); 
		
		CuentaBancariaPojoResponse cuentaBancariaObj=new CuentaBancariaPojoResponse(); 
		PrestamoBancarioPojoResponse prestamoBancarioObj = new PrestamoBancarioPojoResponse();
		TarjetaCreditoPojoResponse tarjetaCreditoObj = new TarjetaCreditoPojoResponse();
		
		//Convirtiendo las fechas de string a date 
		StartDate = dateFormat.DateFormatter(start);
		EndDate = dateFormat.DateFormatter(end);
						
		//Obteniendo meses de diferencia entre las fechas 
		monthsDiff = ChronoUnit.MONTHS.between(StartDate, EndDate) ;
				
		//Desencriptando informacion de SCH
		jwtDecryptList=jWTHelper.DecryptJWT(sch); 
		
		//Obteniendo informacion de cuentas del cliente
		accountList = accountRepository.getProductsForUser(jwtDecryptList.get(0));
				
		//Obteniendo informacion de usuario  
		userEntity = userRepository.findUser(jwtDecryptList.get(0));  
		
		if(userEntity.getUser_client_number().equals(accountList.get(0).getAcc_user_client_number())) {
			if(monthsDiff < 3) {//Verificando si las fechas posee maximo 3 meses de diferencia
				if(StartDate.compareTo(EndDate) < 0) {//Comparando si la fecha de inicio es menor que la fecha final
					 			
					for(int i= 0;i<accountList.size();i++){
						//Obteniendo informacion de transacciones por usuario  
						transactionListEntity = transactionRepositoryResponse.findTransactions(accountList.get(i).getAcc_number(), start, end);
						int product_id = accountList.get(i).getAcc_id_product();
						if(transactionListEntity.size() != 0) {
							transactionObj.setId(transactionListEntity.get(i).getTra_acc_number());
							transactionObj.setDate(transactionListEntity.get(i).getTra_datetime().toString());
							transactionObj.setDescription(transactionListEntity.get(i).getTra_description());
							transactionObj.setAmount(transactionListEntity.get(i).getTra_ammount()); 
							transactionList.add(transactionObj);
							
							switch(product_id){
								case 1://Cuenta bancaria
									cuentaBancariaObj.setId(accountList.get(i).getAcc_number());
									cuentaBancariaObj.setStartDate(start);
									cuentaBancariaObj.setEndDate(end); 
									cuentaBancariaObj.setTransactions(transactionList);
									return new ResponseEntity(cuentaBancariaObj,HttpStatus.OK);
								case 2://Tarjeta de credito
									tarjetaCreditoObj.setId(accountList.get(i).getAcc_number());
									tarjetaCreditoObj.setStartDate(start);
									tarjetaCreditoObj.setEndDate(end);
									tarjetaCreditoObj.setLimit(accountList.get(i).getAcc_limit());
									tarjetaCreditoObj.setAvailable(accountList.get(i).getAcc_available());
									tarjetaCreditoObj.setInterestRate(accountList.get(i).getAcc_interest_rate());
									tarjetaCreditoObj.setInterestAmount(accountList.get(i).getAcc_interest_amount());
									tarjetaCreditoObj.setMonthlyCut(accountList.get(i).getAcc_monthly_cut()); 
									tarjetaCreditoObj.setTransactions(transactionList);
									return new ResponseEntity(tarjetaCreditoObj,HttpStatus.OK);
								case 3://Prestamo bancario
									prestamoBancarioObj.setId(accountList.get(i).getAcc_number());
									prestamoBancarioObj.setStartDate(start);
									prestamoBancarioObj.setEndDate(end);
									prestamoBancarioObj.setTotal(accountList.get(i).getAcc_total());
									prestamoBancarioObj.setDebt(accountList.get(i).getAcc_debt());
									prestamoBancarioObj.setInterestRate(accountList.get(i).getAcc_interest_rate());
									prestamoBancarioObj.setInterestAmount(accountList.get(i).getAcc_interest_amount());
									prestamoBancarioObj.setTransactions(transactionList); 
									return new ResponseEntity(prestamoBancarioObj,HttpStatus.OK);
							}
						}else {
							return new ResponseEntity("No se poseen transacciones en ese periodo de fechas",HttpStatus.BAD_REQUEST);
						}
					}
				}else {//La fecha final es mayor que la inicial
					return new ResponseEntity("La fecha inicial es mayor que la fecha final",HttpStatus.BAD_REQUEST);
				}
				
			}else {//Hay mas de 3 meses de diferencia entre las fechas 
				return new ResponseEntity("Hay una diferencia mayor a 3 meses entre las fechas ingresadas",HttpStatus.BAD_REQUEST);
			}
		} else { // La cuenta no pertenece al usuario
			return new ResponseEntity("La cuenta no pertenece al cliente",HttpStatus.NOT_FOUND);
		} 
		return new ResponseEntity("Error inesperado",HttpStatus.NOT_FOUND);
	}
}
