package com.lifebank.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="TRANSACTIONS")
public class TransactionsEntity {

	@Id  
	@Column(name="tra_id")
	private String tra_id;
	
	@Column(name="tra_acc_number")
	private String tra_acc_number;
	
	@Column(name="tra_id_product")
	private int tra_id_product;
	
	@Column(name="tra_ammount")
	private double tra_ammount;
	
	@Column(name="tra_description")
	private String tra_description;
	
	@Column(name="tra_datetime")
	private Date tra_datetime;

	public String getTra_id() {
		return tra_id;
	}

	public void setTra_id(String tra_id) {
		this.tra_id = tra_id;
	}

	public String getTra_acc_number() {
		return tra_acc_number;
	}

	public void setTra_acc_number(String tra_acc_number) {
		this.tra_acc_number = tra_acc_number;
	}

	public int getTra_id_product() {
		return tra_id_product;
	}

	public void setTra_id_product(int tra_id_product) {
		this.tra_id_product = tra_id_product;
	}

	public double getTra_ammount() {
		return tra_ammount;
	}

	public void setTra_ammount(double tra_ammount) {
		this.tra_ammount = tra_ammount;
	}

	public String getTra_description() {
		return tra_description;
	}

	public void setTra_description(String tra_description) {
		this.tra_description = tra_description;
	}

	public Date getTra_datetime() {
		return tra_datetime;
	}

	public void setTra_datetime(Date tra_datetime) {
		this.tra_datetime = tra_datetime;
	}
 
}
