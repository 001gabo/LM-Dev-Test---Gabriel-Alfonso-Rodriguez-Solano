package com.lifebank.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.lifebank.entity.AccountEntity; 

public interface AccountRepository extends JpaRepository<AccountEntity,Integer>{
	
	@Query(value = "SELECT * FROM account WHERE acc_usuario = :username",
			nativeQuery = true
			)
	public List<AccountEntity> getProductsForUser(@Param("username") String username);
}
