package com.lifebank.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.lifebank.entity.TransactionsEntity;

public interface TransactionsRepository extends JpaRepository<TransactionsEntity, Integer>{
	
	@Query(value = "SELECT * FROM transactions WHERE `tra_acc_number` = :tra_acc_number AND tra_datetime BETWEEN :tra_startdate and :tra_enddate",
			nativeQuery = true
			)
	public List<TransactionsEntity> findTransactions(@Param("tra_acc_number") String tra_acc_number,
			@Param("tra_startdate") String tra_startdate,
			@Param("tra_enddate") String tra_enddate
			);
}
