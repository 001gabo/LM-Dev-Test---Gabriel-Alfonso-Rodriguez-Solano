package com.lifebank.controller;
 
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity; 
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lifebank.pojo.login.request.LoginPojoRequest;
import com.lifebank.pojo.login.response.LoginPojoResponse;
import com.lifebank.process.LoginProcess;
import com.lifebank.repository.UserRepository; 

@RestController
@RequestMapping("/lifebank")
public class LoginController {

	@Autowired
	private UserRepository userRepositoryRequest; 
	private LoginPojoResponse loginResponse;
	 
	@PostMapping("/login")
    public ResponseEntity<?> logIn(@RequestBody LoginPojoRequest loginRequest) {
		loginResponse = new LoginPojoResponse();
		
		LoginProcess loginProc = new LoginProcess(userRepositoryRequest);
		
		loginResponse = loginProc.login(loginRequest);
		if(loginResponse == null){
			return new ResponseEntity<>("Usuario Inactivo, favor contactar con soporte", HttpStatus.UNAUTHORIZED);
		}else {
			return new ResponseEntity<>(loginResponse, HttpStatus.OK);
		}  
		
	}
    
}
