package com.lifebank.process;
 
import java.net.InetAddress; 
 
import org.springframework.stereotype.Service;

import com.lifebank.entity.UserEntity;
import com.lifebank.pojo.login.request.LoginPojoRequest;
import com.lifebank.pojo.login.response.LoginPojoResponse;
import com.lifebank.repository.UserRepository;
import com.lifebank.utility.Cifrado;
import com.lifebank.utility.JWTHelper; 

@Service("LoginProcess")
public class LoginProcess {
	
	private UserRepository userRepositoryRequest;    
	private LoginPojoResponse loginResponse;
	
	public LoginProcess(UserRepository userRepositoryRequest){ 
		this.userRepositoryRequest = userRepositoryRequest;
	}
	
	
	public LoginPojoResponse login(LoginPojoRequest loginRequest) {
		
		UserEntity userResponse;
		loginResponse = new LoginPojoResponse();
		JWTHelper jWTHelper  = new JWTHelper(); 
		Cifrado cifrados = new Cifrado();
		String password; 
		InetAddress iNetAddress;  
		
		password= cifrados.CifradoSha512(cifrados.CifradoBase64(loginRequest.getUser() + loginRequest.getPassword())); 
		
		userResponse = userRepositoryRequest.findUser(loginRequest.getUser()); 
		
		if(loginRequest.getUser().equals(userResponse.getUser_usuario()) && password.equals(userResponse.getUser_password())) {
			try {
				
				iNetAddress = InetAddress.getLocalHost();
				loginResponse.setTkn(jWTHelper.EncryptJWT(loginRequest, iNetAddress.getHostAddress()));
				
			}catch(Exception e) {
				System.out.println("Ha ocurrido un error durante la encriptacion JWT: " + e);
			}  
		} 
		else { 
			System.out.println("Las credenciales ingresasadas no son iguales");
		} 
		return loginResponse;
	}
	
}
