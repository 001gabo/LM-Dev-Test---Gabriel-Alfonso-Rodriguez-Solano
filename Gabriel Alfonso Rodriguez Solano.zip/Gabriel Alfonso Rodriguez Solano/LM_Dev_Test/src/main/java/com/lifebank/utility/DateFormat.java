package com.lifebank.utility;
 
import java.time.LocalDate;
import java.time.format.DateTimeFormatter; 
import java.util.Locale; 

public class DateFormat {
	 
	
	public LocalDate DateFormatter(String fecha) { 
		LocalDate localdate = null;
		localdate= LocalDate.parse(fecha, DateTimeFormatter.ofPattern("yyyy-MM-dd").withLocale(Locale.ENGLISH));
		return localdate;
	}

}
