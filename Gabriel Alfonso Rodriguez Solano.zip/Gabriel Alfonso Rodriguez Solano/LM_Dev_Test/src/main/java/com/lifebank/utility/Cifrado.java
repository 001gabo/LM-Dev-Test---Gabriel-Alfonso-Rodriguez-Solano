package com.lifebank.utility;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;

public class Cifrado {
	
	public String CifradoBase64 (String loginInput) {
		Base64.Encoder encoder = Base64.getEncoder();
		byte[] encoded = encoder.encode(loginInput.getBytes());
		return new String(encoded);
	}
	
	public String CifradoSha512(String passwordToHash){
		String generatedString = null;
		    try {
		         MessageDigest md = MessageDigest.getInstance("SHA-512"); 
		         byte[] bytes = md.digest(passwordToHash.getBytes(StandardCharsets.UTF_8));
		         StringBuilder sb = new StringBuilder();
		         for(int i=0; i< bytes.length ;i++){
		            sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
		         }
		         generatedString = sb.toString();
		        } 
		       catch (Exception e){
		        e.printStackTrace();
		       }
		    return generatedString;
		}
	
}
