package com.lifebank.controller;
 
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lifebank.process.TransactionsProcess;
import com.lifebank.repository.AccountRepository;
import com.lifebank.repository.TransactionsRepository;
import com.lifebank.repository.UserRepository;

@RestController
@RequestMapping("/lifebank")
public class TransactionsController {

	@Autowired 
	private TransactionsRepository transactionRepositoryResponse; 
	@Autowired 
	private UserRepository userRepository;
	@Autowired 
	private AccountRepository accountRepository;
	
	@GetMapping("/transacciones/{accountID}")
    public ResponseEntity<?> getTransacciones(@PathVariable String accountID, 
    		@RequestParam String start, 
    		@RequestParam String end,
    		@RequestHeader("authorization") String sch){
		 
		TransactionsProcess transProc = new TransactionsProcess(transactionRepositoryResponse,userRepository,accountRepository);
		
		return transProc.getTransaccionesProducto(accountID,start,end,sch);
		 
	}
}
