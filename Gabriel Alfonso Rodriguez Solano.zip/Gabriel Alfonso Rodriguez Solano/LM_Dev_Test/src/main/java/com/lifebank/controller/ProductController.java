package com.lifebank.controller;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lifebank.pojo.product.response.ProductPojoResponse;
import com.lifebank.process.ProductProcess;
import com.lifebank.repository.AccountRepository; 

@RestController
@RequestMapping("/lifebank")
public class ProductController {
	
	@Autowired
	private AccountRepository accountRepositoryResponse;  
	private ProductPojoResponse producResponse;
	
	@GetMapping("/productos")
    public ResponseEntity<?> getProducts(@RequestHeader("authorization") String sch){ 
		
		ProductProcess productoProcess = new ProductProcess(accountRepositoryResponse);
		
		producResponse = productoProcess.productoResponse(sch);
		
		if(producResponse == null){
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}else {
			return new ResponseEntity<>(producResponse, HttpStatus.OK);
		}  
	}
	
}
