package com.lifebank.process;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service; 

import com.lifebank.entity.AccountEntity;
import com.lifebank.pojo.product.response.Accounts;
import com.lifebank.pojo.product.response.CreditCard;
import com.lifebank.pojo.product.response.Loan;
import com.lifebank.pojo.product.response.Personal;
import com.lifebank.pojo.product.response.ProductPojoResponse; 
import com.lifebank.repository.AccountRepository;
import com.lifebank.utility.JWTHelper;

@Service("ProductProcess")
public class ProductProcess {
	
	@Autowired
	private AccountRepository accountRepositoryResponse; 
	private ProductPojoResponse producResponse;
	
	public ProductProcess(AccountRepository accountRepositoryResponse) {
		this.accountRepositoryResponse = accountRepositoryResponse;
	}
	
	public ProductPojoResponse productoResponse(String sch) { 
		
		producResponse = new ProductPojoResponse();
		JWTHelper jWTHelper  = new JWTHelper();
		ArrayList<String> jwtDecryptList = new ArrayList<String>();
		List<AccountEntity> accountList = new ArrayList<AccountEntity>();
		
		Accounts account = new Accounts();
		 	
		Personal cuentaBancariaObj = new Personal();
		List<Personal>cuentaBancariaList = new ArrayList<Personal>();
		
		CreditCard tarjetaCreditoObj = new CreditCard();
		List<CreditCard>tarjetaCreditoList = new ArrayList<CreditCard>();
		
		Loan prestamoBancarioObj = new Loan();
		List<Loan>prestamoBancarioList = new ArrayList<Loan>();
		
		jwtDecryptList = jWTHelper.DecryptJWT(sch); 
		accountList = accountRepositoryResponse.getProductsForUser(jwtDecryptList.get(0));
		
		for(int i =0; i<accountList.size(); i++) {
			
			int product_id = accountList.get(i).getAcc_id_product();
			
			if(product_id == 1) {  //cuenta bancaria
				cuentaBancariaObj.setId(String.valueOf(accountList.get(i).getAcc_number())); 
				cuentaBancariaObj.setName(String.valueOf(accountList.get(i).getAcc_tarjeta_habiente()));
				cuentaBancariaList.add(cuentaBancariaObj);
			}else if(product_id == 2) { //tarjeta de credito
				tarjetaCreditoObj.setId(String.valueOf(accountList.get(i).getAcc_number())); 
				tarjetaCreditoObj.setName(String.valueOf(accountList.get(i).getAcc_tarjeta_habiente()));
				tarjetaCreditoList.add(tarjetaCreditoObj);
			}else if(product_id == 3) { //prestamo bancario
				prestamoBancarioObj.setId(String.valueOf(accountList.get(i).getAcc_number()));
				prestamoBancarioObj.setName(String.valueOf(accountList.get(i).getAcc_tarjeta_habiente())); 
				prestamoBancarioList.add(prestamoBancarioObj); 
			}
		}
		account.setLoan(prestamoBancarioList);  
		account.setCreditCard(tarjetaCreditoList);
		account.setPersonal(cuentaBancariaList);
		
		producResponse.setAccounts(account);
		return producResponse;
		
	}
}
	