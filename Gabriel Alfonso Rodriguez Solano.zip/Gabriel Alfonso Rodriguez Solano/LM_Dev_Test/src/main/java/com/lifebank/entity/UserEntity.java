package com.lifebank.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="USER")
public class UserEntity {
	@Id 
	@Column(name="user_client_number") 
	private String user_client_number;
	@Column(name="user_usuario")
	private String user_usuario;
	@Column(name="user_password")
	private String user_password;
	@Column(name="user_names")
	private String user_names;
	@Column(name="user_lastnames")
	private String user_lastnames;
	@Column(name="user_mail") 
	private String user_mail;
	@Column(name="user_status") 
	private String user_status; 
	
	
	public String getUser_usuario() {
		return user_usuario;
	}
	public void setUser_usuario(String user_usuario) {
		this.user_usuario = user_usuario;
	}
	public String getUser_password() {
		return user_password;
	}
	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}
	public String getUser_names() {
		return user_names;
	}
	public void setUser_names(String user_names) {
		this.user_names = user_names;
	}
	public String getUser_lastnames() {
		return user_lastnames;
	}
	public void setUser_lastnames(String user_lastnames) {
		this.user_lastnames = user_lastnames;
	}
	public String getUser_mail() {
		return user_mail;
	}
	public void setUser_mail(String user_mail) {
		this.user_mail = user_mail;
	}
	public String getUser_status() {
		return user_status;
	}
	public void setUser_status(String user_status) {
		this.user_status = user_status;
	}
	public String getUser_client_number() {
		return user_client_number;
	}
	public void setUser_client_number(String user_client_number) {
		this.user_client_number = user_client_number;
	} 
	
	
}
