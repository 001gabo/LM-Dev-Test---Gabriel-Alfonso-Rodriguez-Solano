package com.lifebank.repository;
 
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.lifebank.entity.UserEntity;

public interface UserRepository extends JpaRepository<UserEntity,Integer>{
	
	
	@Query(value = "SELECT  * FROM user WHERE user_usuario = :username",
			nativeQuery = true
			)
	public UserEntity findUser(@Param("username") String username); 
}
