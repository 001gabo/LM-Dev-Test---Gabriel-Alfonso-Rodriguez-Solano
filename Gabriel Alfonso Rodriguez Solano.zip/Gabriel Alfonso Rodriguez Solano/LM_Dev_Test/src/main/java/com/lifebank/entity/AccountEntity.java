package com.lifebank.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="ACCOUNT")
public class AccountEntity {
	
	@Id  
	@Column(name="acc_number")
	private String acc_number;
	
	@Column(name="acc_id_product")
	private int acc_id_product;
	
	@Column(name="acc_user_client_number")
	private String acc_user_client_number;
	
	@Column(name="acc_tarjeta_habiente")
	private String acc_tarjeta_habiente;
	
	@Column(name="acc_ammount")
	private double acc_ammount;
	
	@Column(name="acc_limit")
	private int acc_limit;
	
	@Column(name="acc_available")
	private double acc_available;
	
	@Column(name="acc_interest_rate")
	private double acc_interest_rate;
	
	@Column(name="acc_interest_amount")
	private double acc_interest_amount;
	
	@Column(name="acc_debt")
	private double acc_debt;
	
	@Column(name="acc_total")
	private double acc_total;
	
	@Column(name="acc_monthly_cut")
	private int acc_monthly_cut;
	
	@Column(name="acc_usuario")
	private String acc_usuario;
	
	@Column(name="acc_amount")
	private String acc_amount; 

	public int getAcc_id_product() {
		return acc_id_product;
	}

	public void setAcc_id_product(int acc_id_product) {
		this.acc_id_product = acc_id_product;
	}

	public String getAcc_user_client_number() {
		return acc_user_client_number;
	}

	public void setAcc_user_client_number(String acc_user_client_number) {
		this.acc_user_client_number = acc_user_client_number;
	}

	public String getAcc_tarjeta_habiente() {
		return acc_tarjeta_habiente;
	}

	public void setAcc_tarjeta_habiente(String acc_tarjeta_habiente) {
		this.acc_tarjeta_habiente = acc_tarjeta_habiente;
	}

	public String getAcc_number() {
		return acc_number;
	}

	public void setAcc_number(String acc_number) {
		this.acc_number = acc_number;
	}

	public double getAcc_ammount() {
		return acc_ammount;
	}

	public void setAcc_ammount(double acc_ammount) {
		this.acc_ammount = acc_ammount;
	}

	public int getAcc_limit() {
		return acc_limit;
	}

	public void setAcc_limit(int acc_limit) {
		this.acc_limit = acc_limit;
	}

	public double getAcc_available() {
		return acc_available;
	}

	public void setAcc_available(double acc_available) {
		this.acc_available = acc_available;
	}

	public double getAcc_interest_rate() {
		return acc_interest_rate;
	}

	public void setAcc_interest_rate(double acc_interest_rate) {
		this.acc_interest_rate = acc_interest_rate;
	}

	public double getAcc_interest_amount() {
		return acc_interest_amount;
	}

	public void setAcc_interest_amount(double acc_interest_amount) {
		this.acc_interest_amount = acc_interest_amount;
	}

	public double getAcc_debt() {
		return acc_debt;
	}

	public void setAcc_debt(double acc_debt) {
		this.acc_debt = acc_debt;
	}

	public double getAcc_total() {
		return acc_total;
	}

	public void setAcc_total(double acc_total) {
		this.acc_total = acc_total;
	}

	public int getAcc_monthly_cut() {
		return acc_monthly_cut;
	}

	public void setAcc_monthly_cut(int acc_monthly_cut) {
		this.acc_monthly_cut = acc_monthly_cut;
	}

	public String getAcc_usuario() {
		return acc_usuario;
	}

	public void setAcc_usuario(String acc_usuario) {
		this.acc_usuario = acc_usuario;
	}

	public String getAcc_amount() {
		return acc_amount;
	}

	public void setAcc_amount(String acc_amount) {
		this.acc_amount = acc_amount;
	}
	
	
}
