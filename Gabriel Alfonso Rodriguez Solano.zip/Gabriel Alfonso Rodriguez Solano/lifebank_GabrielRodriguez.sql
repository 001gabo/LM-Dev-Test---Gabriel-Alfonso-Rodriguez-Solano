-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 13-05-2019 a las 02:34:49
-- Versión del servidor: 5.7.19
-- Versión de PHP: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `lifebank`
--
DROP DATABASE IF EXISTS `lifebank`;
CREATE DATABASE IF NOT EXISTS `lifebank` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `lifebank`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `account`
--

DROP TABLE IF EXISTS `account`;
CREATE TABLE IF NOT EXISTS `account` (
  `acc_id_product` int(11) NOT NULL COMMENT 'id del producto',
  `acc_user_client_number` varchar(9) NOT NULL COMMENT 'numero de cliente',
  `acc_tarjeta_habiente` varchar(100) NOT NULL COMMENT 'nombre de tarjeta habiente',
  `acc_number` varchar(10) NOT NULL COMMENT 'numero de cuenta',
  `acc_ammount` double(10,2) DEFAULT NULL COMMENT 'cantidad de la cuenta',
  `acc_limit` int(11) DEFAULT NULL COMMENT 'limite de cuenta',
  `acc_available` double(10,2) DEFAULT NULL COMMENT 'cantidad disponible',
  `acc_interest_rate` double(10,2) DEFAULT NULL COMMENT 'tasa de interes',
  `acc_interest_amount` double(10,2) DEFAULT NULL COMMENT 'cantidad de interes acumulado',
  `acc_debt` double(10,2) DEFAULT NULL COMMENT 'deuda',
  `acc_total` double(10,2) DEFAULT NULL COMMENT 'monto total de prestamo',
  `acc_monthly_cut` int(11) DEFAULT NULL COMMENT 'dida de corte',
  `acc_usuario` varchar(1000) DEFAULT NULL COMMENT 'usuario',
  `acc_amount` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`acc_number`),
  KEY `acc_id_product` (`acc_id_product`),
  KEY `acc_user` (`acc_user_client_number`),
  KEY `acc_prod_FK_idx` (`acc_id_product`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `account`
--

INSERT INTO `account` (`acc_id_product`, `acc_user_client_number`, `acc_tarjeta_habiente`, `acc_number`, `acc_ammount`, `acc_limit`, `acc_available`, `acc_interest_rate`, `acc_interest_amount`, `acc_debt`, `acc_total`, `acc_monthly_cut`, `acc_usuario`, `acc_amount`) VALUES
(1, '048066155', 'Gabriel Rodriguez', 'CB00000001', 1000.00, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 'gaborod', NULL),
(3, '048066155', 'Gabo Rodriguez', 'PB00000001', 1000.00, 0, 0.00, 5.00, 125.00, 3250.00, 7500.00, 0, 'gaborod', NULL),
(2, '048066155', 'Alfonso Solano', 'TC00000001', 0.00, 4500, 3262.00, 5.00, 125.00, 0.00, 0.00, 18, 'gaborod', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `beneficiary`
--

DROP TABLE IF EXISTS `beneficiary`;
CREATE TABLE IF NOT EXISTS `beneficiary` (
  `ben_id` int(11) NOT NULL AUTO_INCREMENT,
  `ben_user` varchar(100) NOT NULL,
  `ben_id_account` varchar(15) NOT NULL,
  `ben_names` varchar(100) NOT NULL,
  `ben_lastnames` varchar(100) NOT NULL,
  `ben_mail` varchar(100) NOT NULL,
  PRIMARY KEY (`ben_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(100) NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `product`
--

INSERT INTO `product` (`product_id`, `product_name`) VALUES
(1, 'Cuenta bancaria'),
(2, 'Tarjeta de credito'),
(3, 'Prestamo bancario');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `transactions`
--

DROP TABLE IF EXISTS `transactions`;
CREATE TABLE IF NOT EXISTS `transactions` (
  `tra_id` int(11) NOT NULL AUTO_INCREMENT,
  `tra_acc_number` varchar(10) NOT NULL COMMENT 'numero de cuenta',
  `tra_id_product` int(11) NOT NULL,
  `tra_ammount` double(10,2) NOT NULL,
  `tra_description` varchar(200) NOT NULL,
  `tra_datetime` date NOT NULL,
  PRIMARY KEY (`tra_id`),
  KEY `transaction_account_FK_idx` (`tra_acc_number`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `transactions`
--

INSERT INTO `transactions` (`tra_id`, `tra_acc_number`, `tra_id_product`, `tra_ammount`, `tra_description`, `tra_datetime`) VALUES
(1, 'CB00000001', 1, 150.00, 'Pago de servicios telefonicos', '2019-05-12'),
(2, 'CB00000001', 1, 15.32, 'Pago de fontaneria', '2019-05-04');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `user_usuario` varchar(1000) NOT NULL,
  `user_password` varchar(1000) NOT NULL,
  `user_names` varchar(100) NOT NULL,
  `user_lastnames` varchar(100) NOT NULL,
  `user_mail` varchar(100) NOT NULL,
  `user_status` varchar(1) NOT NULL,
  `user_client_number` varchar(9) NOT NULL,
  PRIMARY KEY (`user_client_number`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `user`
--

INSERT INTO `user` (`user_usuario`, `user_password`, `user_names`, `user_lastnames`, `user_mail`, `user_status`, `user_client_number`) VALUES
('gaborod', '3ae7d96ae8fa7e1992968e9eee58fd74c75cc7212ee02f399b5cf46717a38fc2745a5a5a1434d39fbf1b66bf42b4d6e1290ffa4145c24b3950d2aca8ef5e02ec', 'Gabriel', 'Rodriguez', 'gabriel@gmail.com', 'A', '048066155');

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `account`
--
ALTER TABLE `account`
  ADD CONSTRAINT `acc_prod_FK` FOREIGN KEY (`acc_id_product`) REFERENCES `product` (`product_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `acc_user_FK` FOREIGN KEY (`acc_user_client_number`) REFERENCES `user` (`user_client_number`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transaction_account_FK` FOREIGN KEY (`tra_acc_number`) REFERENCES `account` (`acc_number`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
